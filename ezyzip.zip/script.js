const vpnIcon = document.getElementById('vpn-icon');
const roundData = document.getElementById('round-data');

// Function to fetch round data
async function fetchRoundData() {
    try {
        const response = await fetch('https://bet7k-aviator-api.p.rapidapi.com/bet7k-aviator-latest', {
            method: 'GET',
            headers: {
                'X-RapidAPI-Key': 'aa95feeaabmsh9d554c50f51582dp122212jsn874613f90d1a',
                'X-RapidAPI-Host': 'bet7k-aviator-api.p.rapidapi.com'
            }
        });

        if (response.ok) {
            const data = await response.json();
            const latestRound = data.data[data.data.length - 1]; // Get the latest round info
            roundData.textContent = `${latestRound.round}x`; // Update round info
        } else {
            console.error('Error fetching round data:', response.statusText);
        }
    } catch (error) {
        console.error('Fetch error:', error);
    }
}

// Function to start fetching round data every few seconds
function startFetching() {
    fetchRoundData(); // Initial fetch
    setInterval(fetchRoundData, 5000); // Fetch every 5 seconds
}

// Start fetching on load
window.onload = startFetching;

import requests
import time
import json

url = "https://bet7k-aviator-api.p.rapidapi.com/bet7k-aviator-latest"
headers = {
    "X-RapidAPI-Key": "aa95feeaabmsh9d554c50f51582dp122212jsn874613f90d1a",
    "X-RapidAPI-Host": "bet7k-aviator-api.p.rapidapi.com"
}

def fetch_current_round():
    while True:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            current_round = data.get('round', 'No data available')  # Adjust based on actual API response
            print("Current Round Data:", current_round)
            # Here, you can implement a way to send this data to your HTML page, e.g., using Flask or a simple WebSocket
        else:
            print(f"Error {response.status_code}: {response.text}")
        
        time.sleep(5)  # Wait for 5 seconds before fetching the data again

if __name__ == "__main__":
    fetch_current_round()
